/*
day03_04 컴포넌트 리팩토링해서 사용
day04_01 children속성 사용하여 완성
useRef() 훅으로 (App_V1.jsx)과 리렌더링 횟수 비교 
*/
import React, { useEffect, useRef, useState } from 'react'
import "./assets/css/TodoInsert.scss";
import "./assets/css/TodoList.scss";
import "./assets/css/TodoListItem.scss";
import "./assets/css/TodoTemplate.scss";
import {
  MdAdd,
  MdCheckBox,
  MdCheckBoxOutlineBlank,
  MdRemoveCircleOutline,
} from "react-icons/md";
import TodoList from './components/TodoList';
import TodoInsert from './components/TodoInsert';
import TodoTemplate from './components/TodoTemplate';

export default function App() {
  const initVal = [
    {
      id: 1,
      text: "리액트 수업 복습",
      checked: true,
    },
    {
      id: 2,
      text: "리액트 프로젝트 기획",
      checked: false,
    },
    {
      id: 3,
      text: "데이터베이스 테스트",
      checked: true,
    },
  ];
  const [todos, setTodos] = useState(initVal);
  const maxid = useRef(todos.length + 1);
  // const [value, setValue] = useState("");

  function handleChecked(id) { //상태변수 변경
    const newtodos = todos.map((item) =>
      item.id === id ? { ...item, checked: !item.checked } : item
    );
    // 상태가 바뀝니다.
    setTodos(newtodos);
  }

  function handleRemove(id) {//상태변수 변경

    const newtodos = todos.filter((item) => item.id !== id);
    setTodos(newtodos);
  }

  const handleInsert = (text) => {//상태변수 변경
    const todo = {
      id: maxid.current,
      text,
      checked: false,
    };

    setTodos([...todos, todo]);

    maxid.current += 1;
  };

  return (
    <div>
      <TodoTemplate>
        {/* 아래의 컴포넌트들은 TodoTemplate의 children 속성으로 사용할 수 있다. */}
        <TodoInsert onInsert={handleInsert} todos={todos}></TodoInsert>
        <TodoList todos={todos} onRemove={handleRemove} onChecked={handleChecked} />
      </TodoTemplate>
      </div>
  )
}



